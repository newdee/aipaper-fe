<template>
  <div>
    <button @click="getList">点击</button>
    <DocumentEditor
      id="docEditor"
      documentServerUrl="https://office.mixpaper.cn/"
      :config="config"
      :events_onDocumentReady="onDocumentReady"
      :onLoadComponentError="onLoadComponentError"
    />
  </div>
</template>

<script lang="ts">
import { defineComponent } from "vue";
import { DocumentEditor } from "@onlyoffice/document-editor-vue";
import { sms } from "@/api/login";

export default defineComponent({
  name: "ExampleComponent",
  components: {
    DocumentEditor,
  },
  data() {
    return {
      config: {
        document: {
          fileType: "docx",
          key: "aipaper",
          title: "Example Document Title.docx",
          url: "https://office.mixpaper.cn/example/editor?fileName=new%20(6).docx",
        },
        documentType: "word",
        editorConfig: {
          callbackUrl: "https://office.mixpaper.cn/example/",
        },
        key: "aipaper",
        token: "aipaper",
      },
    };
  },
  mounted() {
    this.getList();
  },
  methods: {
    getList() {
      // 60秒倒计时
      let data = {
        phone: "17634636466",
        // phone: "13164661907",
      };
      console.log("this.data", data);

      sms(data).then((res) => {});
      // 请求成功

      // 失败
      // this.codeTimeStatus = true;
    },
    onDocumentReady() {
      console.log("Document is loaded");
    },
    onLoadComponentError(errorCode, errorDescription) {
      switch (errorCode) {
        case -1: // Unknown error loading component
          console.log(errorDescription);
          break;

        case -2: // Error load DocsAPI from http://documentserver/
          console.log(errorDescription);
          break;

        case -3: // DocsAPI is not defined
          console.log(errorDescription);
          break;
      }
    },
  },
});
</script>