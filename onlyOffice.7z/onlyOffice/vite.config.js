import { fileURLToPath, URL } from 'node:url'

import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
const port = process.env.port || process.env.npm_config_port || 5173 // dev port

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    vue(),
  ],
  devServer: {
    port: port,
    open: true,
    overlay: {
      warnings: false,
      errors: true
    },
    proxy: {          // 配置跨域处理, 设置代理
      "/dev-api": {
        //  target: `http://localhost:8090/`,
        // target: `http://175.178.88.172:8090/`,
        // target: `http://43.143.210.214:8090/`,
        // target: `http://124.222.112.40:3000/`,
        target: `https://api.mixpaper.cn/`,
        // target: `https://web-proxy.apifox.cn:3000/`,
        changeOrigin: true,
        pathRewrite: {
          '^/dev-api': ''
        }
      },
    },
    // before: require('./mock/mock-server.js')
    disableHostCheck: true
  },
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  }
})
